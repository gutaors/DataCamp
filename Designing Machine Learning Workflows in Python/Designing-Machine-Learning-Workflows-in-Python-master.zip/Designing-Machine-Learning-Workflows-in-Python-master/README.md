# Designing Machine Learning Workflows in Python

The data analysis is documented in [Designing_Machine_Learning_Workflows_in_Python.ipynb](https://github.com/iDataist/Designing-Machine-Learning-Workflows-in-Python/blob/master/Designing_Machine_Learning_Workflows_in_Python.ipynb). The lecture notes and the raw data files are also stored in the repository. The summary of the content is shown below:

- The Standard Workflow

- The Human in the Loop

- Model Lifecycle Management

- Unsupervised Workflows
