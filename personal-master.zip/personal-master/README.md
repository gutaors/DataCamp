# Personal
<b>Description</b>: Personal repository intended to serve as placeholder for various things including personal information, code examples, tutorials/slides, etc

## Scripts
This is to add scipts
